import logo from './logo.svg';
import './App.css';
import { Signup } from './component/signup';
import { Login } from './component/login';
import { MainRoutes } from './component/MainRoutes';
import { Link } from 'react-router-dom';

function App() {

  const signup=false; 

  return (
    <div className="App">
        
     
     <div style={{display:"flex", gap:"50px" ,justifyContent:"space-around" }}>

    <Link to="/"> <h2>Signup</h2></Link> 
    <Link to="/login"><h2>Login</h2></Link> 
     <Link to={"/task"}> <h2>Task</h2>
    </Link>
 </div>
  
 
 

    <MainRoutes/>
   
    </div>
  );
}

export default App;
